# OneNote Exporter — The Process / Branche Aurélien

CLI Python pour extraire sélectivement des pages OneNote via Microsoft Graph API et les exporter en PDF.

## Prérequis

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) (package manager)
- Node.js 18+ (pour Context7 MCP)
- Docker (optionnel)

## Setup rapide

```bash
# 1. Cloner et installer
git clone <repo-url>
cd onenote-exporter
make install

# 2. Configurer Azure AD
cp .env.example .env
# Éditer .env avec ton AZURE_CLIENT_ID (voir docs/SETUP_AZURE.md)

# 3. Tester l'auth
make auth

# 4. Mapper la hiérarchie
make tree

# 5. Exporter
make export
```

## Azure AD Setup (une seule fois)

1. Aller sur [portal.azure.com](https://portal.azure.com)
2. Azure Active Directory → App registrations → New registration
3. Nom : `onenote-exporter`, Supported accounts : Personal + Organizational
4. Redirect URI : `http://localhost` (type Web)
5. Copier l'Application (client) ID → `AZURE_CLIENT_ID` dans `.env`
6. API Permissions → Add → Microsoft Graph → Delegated → `Notes.Read`
7. C'est tout — pas besoin de client secret pour le device code flow

## Développement

Ce projet utilise le **Golden Workflow** avec 10 agents Claude Code spécialisés.

```bash
make test             # Tests (fail fast)
make test-cov         # Tests + couverture
make lint             # Linting + format check
make typecheck        # Vérification de types
make format           # Auto-format
make docker-build     # Build Docker
```

## Structure Claude Code

Le `.claude/` de ce projet contient 10 agents couvrant les 7 étapes du Golden Workflow :

| Étape | Agents |
|-------|--------|
| CDC | orchestrator, cdc-validator |
| Plan | architect |
| TDD | tdd-engineer |
| Review | code-reviewer, security-auditor, performance-reviewer |
| Verify | quality-gate-keeper |
| Infra | infra-engineer |
| Refactor | refactor-guide |

## Licence

MIT
