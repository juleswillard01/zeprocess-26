"""Tests pour le mapping de hiérarchie OneNote."""

from src.hierarchy import HierarchyNode


class TestHierarchyNode:
    """Tests pour la structure de l'arbre de hiérarchie."""

    def test_leaf_node_total_pages_equals_page_count(self) -> None:
        """Un nœud feuille doit avoir total_pages == page_count."""
        node = HierarchyNode(name="Section A", node_type="section", id="s-1", page_count=12)
        assert node.total_pages == 12

    def test_parent_node_sums_children_pages(self) -> None:
        """Un nœud parent doit sommer les pages de ses enfants."""
        child_a = HierarchyNode(name="A", node_type="section", id="s-1", page_count=10)
        child_b = HierarchyNode(name="B", node_type="section", id="s-2", page_count=5)
        parent = HierarchyNode(
            name="Notebook", node_type="notebook", id="nb-1", children=[child_a, child_b]
        )
        assert parent.total_pages == 15

    def test_nested_hierarchy_counts_all_levels(self) -> None:
        """Le comptage doit traverser tous les niveaux de profondeur."""
        page = HierarchyNode(name="Sec", node_type="section", id="s-1", page_count=3)
        group = HierarchyNode(
            name="Group", node_type="section_group", id="g-1", children=[page]
        )
        notebook = HierarchyNode(
            name="NB", node_type="notebook", id="nb-1", children=[group]
        )
        assert notebook.total_pages == 3

    def test_empty_node_has_zero_pages(self) -> None:
        """Un nœud sans pages et sans enfants doit avoir 0 pages."""
        node = HierarchyNode(name="Vide", node_type="section", id="s-0")
        assert node.total_pages == 0
