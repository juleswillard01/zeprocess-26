"""Tests pour le client Microsoft Graph API."""

from src.graph import GraphClient, Notebook, Page, Section


class TestGraphModels:
    """Tests pour les dataclasses du module graph."""

    def test_notebook_has_required_fields(self) -> None:
        """Un Notebook doit avoir un id et un display_name."""
        nb = Notebook(id="nb-1", display_name="Mon Notebook")
        assert nb.id == "nb-1"
        assert nb.display_name == "Mon Notebook"

    def test_section_has_notebook_reference(self) -> None:
        """Une Section doit référencer son notebook parent."""
        section = Section(id="sec-1", display_name="Section A", notebook_id="nb-1")
        assert section.notebook_id == "nb-1"

    def test_page_has_default_order_zero(self) -> None:
        """Une Page doit avoir un ordre par défaut de 0."""
        page = Page(id="p-1", title="Page 1", section_id="sec-1", created_date_time="2025-01-01")
        assert page.order == 0


class TestGraphClient:
    """Tests pour le client Graph API."""

    def test_client_stores_token(self) -> None:
        """Le client doit stocker le token fourni."""
        client = GraphClient(access_token="test-token-123")
        assert client._token == "test-token-123"
