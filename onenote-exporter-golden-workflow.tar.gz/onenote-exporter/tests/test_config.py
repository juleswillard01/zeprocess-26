"""Tests pour la configuration."""

from pathlib import Path

from src.config import Settings, get_settings


class TestSettings:
    """Tests pour la classe Settings."""

    def test_default_settings_have_sane_defaults(self) -> None:
        """Les settings par défaut doivent avoir des valeurs raisonnables."""
        settings = Settings(azure_client_id="test-id")
        assert settings.azure_tenant_id == "common"
        assert settings.graph_rate_limit == 4
        assert settings.max_pages == 150
        assert settings.cache_ttl_seconds == 3600

    def test_export_output_dir_is_path(self) -> None:
        """Le dossier d'export doit être un Path."""
        settings = Settings(azure_client_id="test-id")
        assert isinstance(settings.export_output_dir, Path)

    def test_get_settings_returns_settings_instance(self) -> None:
        """get_settings doit retourner une instance Settings."""
        settings = get_settings()
        assert isinstance(settings, Settings)
