"""Tests pour l'export PDF."""

from pathlib import Path

from src.exporter import ExportReport, ExportResult


class TestExportResult:
    """Tests pour le résultat d'export d'une page."""

    def test_successful_result_has_no_error(self) -> None:
        """Un export réussi ne doit pas avoir d'erreur."""
        result = ExportResult(
            page_title="Test",
            pdf_path=Path("out/test.pdf"),
            success=True,
        )
        assert result.success is True
        assert result.error is None

    def test_failed_result_has_error_message(self) -> None:
        """Un export échoué doit avoir un message d'erreur."""
        result = ExportResult(
            page_title="Test",
            pdf_path=Path("out/test.pdf"),
            success=False,
            error="WeasyPrint conversion failed",
        )
        assert result.success is False
        assert result.error is not None


class TestExportReport:
    """Tests pour le rapport d'export."""

    def test_success_rate_full_success(self) -> None:
        """100% si tout est exporté."""
        report = ExportReport(
            total_pages=10, exported=10, failed=0, total_size_bytes=1024, results=[]
        )
        assert report.success_rate == 100.0

    def test_success_rate_partial(self) -> None:
        """Calcul correct pour un export partiel."""
        report = ExportReport(
            total_pages=10, exported=7, failed=3, total_size_bytes=512, results=[]
        )
        assert report.success_rate == 70.0

    def test_success_rate_zero_pages(self) -> None:
        """0% si aucune page à exporter."""
        report = ExportReport(
            total_pages=0, exported=0, failed=0, total_size_bytes=0, results=[]
        )
        assert report.success_rate == 0.0
