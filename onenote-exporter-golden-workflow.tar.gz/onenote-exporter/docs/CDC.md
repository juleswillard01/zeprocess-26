# CDC — OneNote Exporter

## 1. Authentification
### 1.1 Azure AD OAuth2
- Device code flow (pas de redirect browser)
- Permissions : `Notes.Read` (lecture seule)
- Refresh automatique du token avant expiration (~1h)
- Stockage token en mémoire uniquement (jamais sur disque)

### 1.2 Configuration
- `AZURE_CLIENT_ID` et `AZURE_TENANT_ID` via `.env`
- Pas de `client_secret` nécessaire pour device code flow
- Support du tenant `common` pour comptes personnels

## 2. Mapping Hiérarchie
### 2.1 Arbre complet
- Lister tous les notebooks de l'utilisateur
- Pour chaque notebook : lister les section groups (récursif)
- Pour chaque section : lister les pages (avec pagination)
- Afficher le nombre de pages par section et le total

### 2.2 Affichage
- Format arbre (tree) avec indentation
- Compteur de pages par nœud : `Section A (12 pages)`
- Total en bas : `Total : 347 pages`
- Couleurs via `rich` pour la lisibilité

### 2.3 Cache
- Cacher la hiérarchie dans `io/cache/hierarchy.json`
- TTL configurable (défaut : 1h)
- Option `--no-cache` pour forcer le refresh

## 3. Sélection
### 3.1 Mode interactif
- Afficher l'arbre puis demander la sélection
- Sélection par numéro de section ou nom
- Support multi-sélection : `1,3,5` ou `1-5`

### 3.2 Mode CLI
- `--sections "Section A,Section B"` pour sélection directe
- `--all` pour tout exporter (avec confirmation si > 200 pages)
- `--max-pages 150` pour limiter automatiquement

## 4. Export
### 4.1 Récupération contenu
- Fetch du HTML de chaque page via Graph API
- Téléchargement des images embarquées
- Respect du rate limit : 4 req/s max, backoff exponentiel sur 429

### 4.2 Conversion PDF
- HTML → PDF via WeasyPrint
- Un PDF par page OneNote
- Nommage : `{section}/{ordre}_{titre_page}.pdf`
- Dossier de sortie : `io/exports/`

### 4.3 Rapport
- Barre de progression pendant l'export
- Rapport final : nombre de pages exportées, taille totale, erreurs
- Log des erreurs dans `io/exports/errors.log`

## 5. CLI
### 5.1 Commandes
- `onenote-export tree` : afficher la hiérarchie
- `onenote-export export` : exporter les pages sélectionnées
- `onenote-export auth` : tester l'authentification

### 5.2 Options globales
- `--verbose` / `-v` : mode debug
- `--no-cache` : ignorer le cache
- `--output-dir` : dossier de sortie custom

## 6. Infrastructure
### 6.1 Docker
- Image basée sur `python:3.12-slim`
- WeasyPrint et ses dépendances système
- Volume monté pour `io/`

### 6.2 Qualité
- Tests : couverture ≥ 80%
- Lint : ruff + pyright strict
- CI : lint → test → build (GitHub Actions)
