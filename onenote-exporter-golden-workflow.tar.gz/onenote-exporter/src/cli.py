"""Point d'entrée CLI pour OneNote Exporter."""

import click


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Mode debug")
@click.option("--no-cache", is_flag=True, help="Ignorer le cache")
@click.pass_context
def main(ctx: click.Context, verbose: bool, no_cache: bool) -> None:
    """OneNote Exporter — Extraire les pages OneNote en PDF."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["no_cache"] = no_cache


@main.command()
@click.pass_context
def auth(ctx: click.Context) -> None:
    """Tester l'authentification Azure AD."""
    raise NotImplementedError("À implémenter — CDC §1.1")


@main.command()
@click.pass_context
def tree(ctx: click.Context) -> None:
    """Afficher la hiérarchie OneNote avec comptage de pages."""
    raise NotImplementedError("À implémenter — CDC §2.2")


@main.command()
@click.option("--sections", "-s", help="Sections à exporter (séparées par virgule)")
@click.option("--all", "export_all", is_flag=True, help="Exporter tout")
@click.option("--max-pages", type=int, default=150, help="Limite de pages")
@click.option("--output-dir", "-o", type=click.Path(), help="Dossier de sortie")
@click.pass_context
def export(
    ctx: click.Context,
    sections: str | None,
    export_all: bool,
    max_pages: int,
    output_dir: str | None,
) -> None:
    """Exporter les pages sélectionnées en PDF."""
    raise NotImplementedError("À implémenter — CDC §3 + §4")


if __name__ == "__main__":
    main()
