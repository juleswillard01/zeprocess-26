"""Client Microsoft Graph API pour OneNote."""

from dataclasses import dataclass


@dataclass
class Notebook:
    """Représente un notebook OneNote."""

    id: str
    display_name: str


@dataclass
class Section:
    """Représente une section OneNote."""

    id: str
    display_name: str
    notebook_id: str


@dataclass
class Page:
    """Représente une page OneNote."""

    id: str
    title: str
    section_id: str
    created_date_time: str
    order: int = 0


class GraphClient:
    """Client pour l'API Microsoft Graph OneNote."""

    def __init__(self, access_token: str) -> None:
        """Initialise le client avec un access token."""
        self._token = access_token

    async def list_notebooks(self) -> list[Notebook]:
        """Liste tous les notebooks de l'utilisateur.

        Returns:
            Liste de notebooks.

        Raises:
            GraphAPIError: Si l'appel API échoue.
        """
        raise NotImplementedError("À implémenter — CDC §2.1")

    async def list_sections(self, notebook_id: str) -> list[Section]:
        """Liste les sections d'un notebook.

        Args:
            notebook_id: ID du notebook.

        Returns:
            Liste de sections.
        """
        raise NotImplementedError("À implémenter — CDC §2.1")

    async def list_pages(self, section_id: str) -> list[Page]:
        """Liste les pages d'une section.

        Args:
            section_id: ID de la section.

        Returns:
            Liste de pages.
        """
        raise NotImplementedError("À implémenter — CDC §2.1")

    async def get_page_content(self, page_id: str) -> str:
        """Récupère le contenu HTML d'une page.

        Args:
            page_id: ID de la page.

        Returns:
            Contenu HTML de la page.
        """
        raise NotImplementedError("À implémenter — CDC §4.1")
