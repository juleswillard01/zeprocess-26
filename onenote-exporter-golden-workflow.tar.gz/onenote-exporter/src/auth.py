"""Authentification Azure AD via MSAL device code flow."""


def authenticate() -> str:
    """Authentifie l'utilisateur et retourne un access token.

    Utilise le device code flow MSAL pour obtenir un token
    sans nécessiter de client_secret.

    Returns:
        Access token valide pour Microsoft Graph API.

    Raises:
        AuthenticationError: Si l'authentification échoue.
    """
    raise NotImplementedError("À implémenter — CDC §1.1")
