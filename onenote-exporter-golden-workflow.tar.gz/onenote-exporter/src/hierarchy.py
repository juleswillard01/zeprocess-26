"""Mapping de la hiérarchie OneNote en arbre avec comptage de pages."""

from dataclasses import dataclass, field


@dataclass
class HierarchyNode:
    """Nœud dans l'arbre de hiérarchie OneNote."""

    name: str
    node_type: str  # "notebook", "section_group", "section"
    id: str
    page_count: int = 0
    children: list["HierarchyNode"] = field(default_factory=list)

    @property
    def total_pages(self) -> int:
        """Nombre total de pages incluant les enfants."""
        return self.page_count + sum(c.total_pages for c in self.children)


def build_tree() -> list[HierarchyNode]:
    """Construit l'arbre de hiérarchie complet depuis l'API Graph.

    Returns:
        Liste de nœuds racine (notebooks).

    Raises:
        GraphAPIError: Si un appel API échoue.
    """
    raise NotImplementedError("À implémenter — CDC §2.1")


def display_tree(nodes: list[HierarchyNode], indent: int = 0) -> str:
    """Formate l'arbre pour affichage console.

    Args:
        nodes: Liste de nœuds à afficher.
        indent: Niveau d'indentation.

    Returns:
        Représentation texte de l'arbre.
    """
    raise NotImplementedError("À implémenter — CDC §2.2")
